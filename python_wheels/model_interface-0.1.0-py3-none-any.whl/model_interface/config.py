MODEL_CONFIG = {
    "model_a": "my_package.models.model_a:ModelA",
    "model_b": "my_package.models.model_b:ModelB",
}
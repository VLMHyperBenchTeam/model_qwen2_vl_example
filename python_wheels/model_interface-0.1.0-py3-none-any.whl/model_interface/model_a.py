from .model_interface import ModelInterface

class ModelA(ModelInterface):
    def predict_on_image(self, image, question):
        """Метод для предсказания по одному изображению."""
        print("ModelA predict_on_image")

    def predict_on_images(self, images, question):
        """Метод для предсказания по нескольким изображениям."""
        print("ModelA predict_on_images")

    def print(self):
        print("ModelA")
        